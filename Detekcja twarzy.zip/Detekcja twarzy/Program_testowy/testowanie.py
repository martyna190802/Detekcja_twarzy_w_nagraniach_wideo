from collections import Counter
import matplotlib.pyplot as plt


etykiety = open("etykiety.txt")
dane = open("output_data.txt")

etykietyTab = []
daneTab = []
cnn = []
hog = []

for i in etykiety:
    etykietyTab.append(i) 
for i in dane:
    daneTab.append(i)


for entry in daneTab:
    entryTab = entry.split(sep=';')
    #print(entryTab)
    for line in etykietyTab:
        etykieta = line.split(sep=';')
        #print(etykieta)
        if entryTab[0] == etykieta[0]:
            #print('git')
            foundFacesCount = int(entryTab[1]) * 100 / int(etykieta[1])
            foundFaces = entryTab[2].split(sep=',')
            knownFaces = etykieta[2].split(sep=',')
            for i in range(len(foundFaces)):
                foundFaces[i] = foundFaces[i].strip()
            for i in range(len(knownFaces)):
                knownFaces[i] = knownFaces[i].strip()
            
            compare = lambda x,y : Counter(x) == Counter(y)

            difference = list(set(knownFaces).symmetric_difference(set(foundFaces)))
            notFound = [i for i in difference if i in knownFaces]
            missFound = [i for i in difference if i not in knownFaces]

            if compare(knownFaces,foundFaces) == True:
                print('W pliku: ' + str(entryTab[0]) + ' używając modelu: ' + entryTab[3].strip() + ', znaleziono: ' + entryTab[1] + ' z ' + etykieta[1] + ' twarzy (' + str(foundFacesCount) + '%). Twarze te są zgodne z etykietą')
            else:
                if len(notFound) != 0 and len(missFound):
                    print('W pliku: ' + str(entryTab[0]) + ' używając modelu: ' + entryTab[3].strip() + ', znaleziono: ' + entryTab[1] + ' z ' + etykieta[1] + ' twarzy (' + str(foundFacesCount) + '%). Twarze te nie są zgodne z etykietą. Nie zidentyfikowano: ' + str(notFound) +' Niepoprawnie zidentyfikowano: ' + str(missFound))
                elif len(notFound) == 0 and len(missFound):
                    print('W pliku: ' + str(entryTab[0]) + ' używając modelu: ' + entryTab[3].strip() + ', znaleziono: ' + entryTab[1] + ' z ' + etykieta[1] + ' twarzy (' + str(foundFacesCount) + '%). Twarze te nie są zgodne z etykietą. Niepoprawnie zidentyfikowano: ' + str(missFound))
                else:
                    print('W pliku: ' + str(entryTab[0]) + ' używając modelu: ' + entryTab[3].strip() + ', znaleziono: ' + entryTab[1] + ' z ' + etykieta[1] + ' twarzy (' + str(foundFacesCount) + '%). Twarze te nie są zgodne z etykietą. Nie zidentyfikowano: ' + str(notFound))
            
            if entryTab[3].strip() == 'cnn':
                cnn.append(foundFacesCount)
            else:
                hog.append(foundFacesCount)
cnnSum = 0
hogSum = 0
for i in cnn:
    cnnSum += float(i)
for i in hog:
    hogSum += float(i)
if len(hog) != 0 and len(cnn) != 0:
    cnnMean = cnnSum / len(cnn)
    hogMean = hogSum / len(hog)
    fig, ax = plt.subplots()

    xvalues = ['hog', 'cnn']
    ax.bar([1,2],[hogMean,cnnMean],0.8)
    #ax.bar(2+0.3/2,cnnMean,0.3,label='cnn')
    ax.set_yticks([0,10,20,30,40,50,60,70,80,90,100])
    ax.set_xticks([1,2])
    ax.set_xticklabels(['hog','cnn'])
    ax.set_title(f'Liczba wykrytych twarzy [%]\nIlość danych CNN: {len(cnn)} zdjęć oraz HOG: {len(hog)} zdjęć\nCNN:{cnnMean}% HOG: {hogMean}%')
    
    #ax.legend()
    plt.show()

